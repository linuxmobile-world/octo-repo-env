#!/bin/sh
accli -t clean-device::CUDOrRFS || exit 1
for x in ssl wifi smime codesign ; do
	if [ -f /var/lib/aegis/ps/Ss/certman.$x-ca ] ; then
		apscli -s certman.$x-ca:Ss -D
	fi
done
exit 0
