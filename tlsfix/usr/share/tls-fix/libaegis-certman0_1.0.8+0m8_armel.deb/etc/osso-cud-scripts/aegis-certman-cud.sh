#!/bin/sh
accli -t clean-device::CUDOrRFS || exit 1
cd /var/lib/aegis/certs/user/
for x in ssl wifi smime codesign ; do
	if [ -f /var/lib/aegis/ps/Ss/certman.$x-user ] ; then
		cd $x-user
		for k in *.pem ; do
			if [ -f "/var/lib/aegis/certs/keys/$k" ] ; then
				rm -f /var/lib/aegis/certs/keys/$k
			fi
		done
		cd ..
		apscli -s certman.$x-user:Ss -D
	fi
done
exit 0
