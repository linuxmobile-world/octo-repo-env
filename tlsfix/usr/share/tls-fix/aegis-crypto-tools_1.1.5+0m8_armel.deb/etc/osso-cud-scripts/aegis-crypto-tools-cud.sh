#!/bin/sh
accli -t clean-device::CUDOrRFS || exit 1
# Delete all encrypted content
for x in `apscli -lu | grep \:.e` ; do
	apscli -s $x -D
done
exit 0
