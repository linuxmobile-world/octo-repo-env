#!/bin/sh

BACKUP_ROOT=/tmp/certman_backup
AEGIS_ROOT=/var/lib/aegis
APSMERGE=/usr/bin/apsmerge
BACKUP_TOKEN="backup-framework::backup"
ACMCLI=/usr/bin/acmcli
BACKUP_STORES="codesign-ca codesign-user smime-ca smime-user ssl-ca ssl-user wifi-ca wifi-user"

CREDS=`$APSMERGE -I | grep -i "^[[:space:]]$BACKUP_TOKEN$"`

if [ -z "$CREDS" ]; then
  echo "This script can only be invoked by the backup framework"
  exit 2
fi

#Make sure we start fresh
rm -rf $BACKUP_ROOT
mkdir -p $BACKUP_ROOT

#Copy all user installed certificates & keys
#Note: at this point we are only copying the known stores
#      defined in BACKUP_STORES
mkdir -p $BACKUP_ROOT/user
mkdir -p $BACKUP_ROOT/stores

for STORE in $BACKUP_STORES; do
  cp -arf $AEGIS_ROOT/certs/user/$STORE $BACKUP_ROOT/user
  #Copy all private certman stores index files
  cp -af $AEGIS_ROOT/ps/Ss/certman.$STORE $BACKUP_ROOT/stores
done

cp -arf $AEGIS_ROOT/certs/keys $BACKUP_ROOT
# filter the key to make sure we backup
# only encrypted ones
for i in $BACKUP_ROOT/keys/*; do
  KEY_ID=`basename $i .pem`
  # check if the key is unencrypted and remove it
  echo | $ACMCLI -k $KEY_ID
  if [ "$?" == "0" ]; then
    rm -f $i
  fi
  # Check if the coresponding certificate was backed up
  # If not don't back it up
  KEY_CERT=`find $BACKUP_ROOT/user -name $KEY_ID.pem`
  if [ -z $KEY_CERT ]; then
    rm -f $i
  fi
done

#Ensure a success on exit
exit 0
