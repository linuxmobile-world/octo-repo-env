#!/bin/sh
BACKUP_ROOT=/tmp/certman_backup                          
AEGIS_ROOT=/var/lib/aegis
APSMERGE=/usr/bin/apsmerge
BACKUP_TOKEN="backup-framework::backup"

CREDS=`$APSMERGE -I | grep -i "^[[:space:]]$BACKUP_TOKEN$"`

if [ -z "$CREDS" ]; then
  echo "This script can only be invoked by the backup framework"
  exit 2
fi

#In some cases the backup framework does not include empty folders
#so there is nothing to restore -> Success
if [ ! -d $BACKUP_ROOT ]; then exit 0; fi

if [ ! -d $AEGIS_ROOT/certs/user ]; then mkdir -pf $AEGIS_ROOT/certs/user; fi
if [ ! -d $AEGIS_ROOT/certs/keys ]; then mkdir -pf $AEGIS_ROOT/certs/keys; fi

#restore the user installed certificates and private keys
cp -ar $BACKUP_ROOT/user/* $AEGIS_ROOT/certs/user
cp -ar $BACKUP_ROOT/keys/* $AEGIS_ROOT/certs/keys

#restore the private stores index files(and merge in case it's needed)
for i in $BACKUP_ROOT/stores/*; do
  STORE=`basename $i`
  # check if the store index already exists
  if [ ! -f $AEGIS_ROOT/ps/Ss/$STORE ]; then
    #Just copy the index file back
    cp -a $i $AEGIS_ROOT/ps/Ss/$STORE
  else
    #Merge the index files
    echo Merging $STORE
    $APSMERGE -s $STORE:Ss -m $BACKUP_ROOT/stores/$STORE
    if [ $? == "0" ]; then 
      echo Success!
    fi
      #cp -a $i $AEGIS_ROOT/ps/Ss/$STORE.backup
  fi
done
exit 0
